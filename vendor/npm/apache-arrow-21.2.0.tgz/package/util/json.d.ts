/** @ignore */
export declare function parseArrowJSON(source: string): any;
